package net.zzong.jdbcex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.object.SqlQuery;

import javax.activation.DataSource;
import java.util.List;

/**
 * Created by 김종인 on 2017-02-27.
 */
public class GenericSqlQueryExample {
    @Autowired
    private DataSource dataSource;
    private SqlQuery<User> userSqlQuery;

    private RowMapper<User> createUserRowMapper(){
        return (rs, rowNum) -> {
            User user = new User();
            user.setId(rs.getLong("id"));
            user.setName(rs.getString("name"));
            user.setEmail(rs.getString("email"));
            user.setRegdt(rs.getDate("regdt"));
            return user;
        };
    }

    public void runExample() {
        User person = loadPersonById(1);
        System.out.printf("Person loaded: %s%n", person);
        person = loadPersonById(2);
        System.out.printf("Person loaded: %s%n", person);
    }

    public User loadPersonById(long id) {
        List<User> persons = userSqlQuery.execute(id);
        if (persons.size() == 1) {
            return persons.get(0);
        }
        return null;
    }
}
